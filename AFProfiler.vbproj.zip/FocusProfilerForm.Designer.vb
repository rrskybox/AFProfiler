﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FocusProfilerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ProfileDataBox = New System.Windows.Forms.TextBox()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.StopButton = New System.Windows.Forms.Button()
        Me.DoneButton = New System.Windows.Forms.Button()
        Me.FirstFilterNumber = New System.Windows.Forms.NumericUpDown()
        Me.FirstFilterLabel = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LastFilterNumber = New System.Windows.Forms.NumericUpDown()
        Me.ZBFSLabel = New System.Windows.Forms.Label()
        Me.PreFocusButton = New System.Windows.Forms.Button()
        Me.FocusFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.ClearFilterLabel = New System.Windows.Forms.Label()
        Me.ClearFilterNumber = New System.Windows.Forms.NumericUpDown()
        Me.AFToolTips = New System.Windows.Forms.ToolTip(Me.components)
        Me.RepetitionsNumber = New System.Windows.Forms.NumericUpDown()
        Me.RepetitionsLabel = New System.Windows.Forms.Label()
        Me.WaitLabel = New System.Windows.Forms.Label()
        Me.WaitNumber = New System.Windows.Forms.NumericUpDown()
        Me.ExposureNumber = New System.Windows.Forms.NumericUpDown()
        Me.ExposureLabel = New System.Windows.Forms.Label()
        Me.AnalyzeButton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ReferenceFilter = New System.Windows.Forms.NumericUpDown()
        Me.ReferenceTemperature = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TemperatureReadout = New System.Windows.Forms.Label()
        CType(Me.FirstFilterNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LastFilterNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClearFilterNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepetitionsNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WaitNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ExposureNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReferenceFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReferenceTemperature, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ProfileDataBox
        '
        Me.ProfileDataBox.Location = New System.Drawing.Point(9, 14)
        Me.ProfileDataBox.Multiline = True
        Me.ProfileDataBox.Name = "ProfileDataBox"
        Me.ProfileDataBox.ReadOnly = True
        Me.ProfileDataBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.ProfileDataBox.Size = New System.Drawing.Size(631, 281)
        Me.ProfileDataBox.TabIndex = 0
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(424, 383)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(70, 26)
        Me.StartButton.TabIndex = 1
        Me.StartButton.Text = "Start"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'StopButton
        '
        Me.StopButton.Location = New System.Drawing.Point(500, 383)
        Me.StopButton.Name = "StopButton"
        Me.StopButton.Size = New System.Drawing.Size(70, 26)
        Me.StopButton.TabIndex = 2
        Me.StopButton.Text = "Stop"
        Me.StopButton.UseVisualStyleBackColor = True
        '
        'DoneButton
        '
        Me.DoneButton.Location = New System.Drawing.Point(576, 383)
        Me.DoneButton.Name = "DoneButton"
        Me.DoneButton.Size = New System.Drawing.Size(70, 26)
        Me.DoneButton.TabIndex = 4
        Me.DoneButton.Text = "Cancel"
        Me.DoneButton.UseVisualStyleBackColor = True
        '
        'FirstFilterNumber
        '
        Me.FirstFilterNumber.Location = New System.Drawing.Point(229, 298)
        Me.FirstFilterNumber.Maximum = New Decimal(New Integer() {7, 0, 0, 0})
        Me.FirstFilterNumber.Name = "FirstFilterNumber"
        Me.FirstFilterNumber.Size = New System.Drawing.Size(32, 20)
        Me.FirstFilterNumber.TabIndex = 5
        '
        'FirstFilterLabel
        '
        Me.FirstFilterLabel.AutoSize = True
        Me.FirstFilterLabel.Location = New System.Drawing.Point(172, 300)
        Me.FirstFilterLabel.Name = "FirstFilterLabel"
        Me.FirstFilterLabel.Size = New System.Drawing.Size(51, 13)
        Me.FirstFilterLabel.TabIndex = 6
        Me.FirstFilterLabel.Text = "First Filter"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(281, 300)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Last Filter"
        '
        'LastFilterNumber
        '
        Me.LastFilterNumber.Location = New System.Drawing.Point(339, 298)
        Me.LastFilterNumber.Maximum = New Decimal(New Integer() {7, 0, 0, 0})
        Me.LastFilterNumber.Name = "LastFilterNumber"
        Me.LastFilterNumber.Size = New System.Drawing.Size(31, 20)
        Me.LastFilterNumber.TabIndex = 7
        Me.LastFilterNumber.Value = New Decimal(New Integer() {3, 0, 0, 0})
        '
        'ZBFSLabel
        '
        Me.ZBFSLabel.AutoSize = True
        Me.ZBFSLabel.Location = New System.Drawing.Point(8, 298)
        Me.ZBFSLabel.Name = "ZBFSLabel"
        Me.ZBFSLabel.Size = New System.Drawing.Size(137, 13)
        Me.ZBFSLabel.TabIndex = 9
        Me.ZBFSLabel.Text = "Zero Based Filter Selection:"
        '
        'PreFocusButton
        '
        Me.PreFocusButton.Location = New System.Drawing.Point(9, 334)
        Me.PreFocusButton.Name = "PreFocusButton"
        Me.PreFocusButton.Size = New System.Drawing.Size(70, 26)
        Me.PreFocusButton.TabIndex = 10
        Me.PreFocusButton.Text = "Pre-Focus"
        Me.PreFocusButton.UseVisualStyleBackColor = True
        '
        'FocusFileDialog
        '
        Me.FocusFileDialog.FileName = "*.foc"
        Me.FocusFileDialog.InitialDirectory = "C:\Users\*\Documents\Software Bisque\TheSkyX Professional Edition\Focuser Data"
        '
        'ClearFilterLabel
        '
        Me.ClearFilterLabel.AutoSize = True
        Me.ClearFilterLabel.Location = New System.Drawing.Point(401, 300)
        Me.ClearFilterLabel.Name = "ClearFilterLabel"
        Me.ClearFilterLabel.Size = New System.Drawing.Size(56, 13)
        Me.ClearFilterLabel.TabIndex = 11
        Me.ClearFilterLabel.Text = "Clear Filter"
        '
        'ClearFilterNumber
        '
        Me.ClearFilterNumber.Location = New System.Drawing.Point(463, 298)
        Me.ClearFilterNumber.Maximum = New Decimal(New Integer() {7, 0, 0, 0})
        Me.ClearFilterNumber.Name = "ClearFilterNumber"
        Me.ClearFilterNumber.Size = New System.Drawing.Size(31, 20)
        Me.ClearFilterNumber.TabIndex = 12
        Me.ClearFilterNumber.Value = New Decimal(New Integer() {3, 0, 0, 0})
        '
        'RepetitionsNumber
        '
        Me.RepetitionsNumber.Location = New System.Drawing.Point(151, 340)
        Me.RepetitionsNumber.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.RepetitionsNumber.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.RepetitionsNumber.Name = "RepetitionsNumber"
        Me.RepetitionsNumber.Size = New System.Drawing.Size(45, 20)
        Me.RepetitionsNumber.TabIndex = 13
        Me.RepetitionsNumber.Value = New Decimal(New Integer() {12, 0, 0, 0})
        '
        'RepetitionsLabel
        '
        Me.RepetitionsLabel.AutoSize = True
        Me.RepetitionsLabel.Location = New System.Drawing.Point(85, 342)
        Me.RepetitionsLabel.Name = "RepetitionsLabel"
        Me.RepetitionsLabel.Size = New System.Drawing.Size(60, 13)
        Me.RepetitionsLabel.TabIndex = 14
        Me.RepetitionsLabel.Text = "Repetitions"
        '
        'WaitLabel
        '
        Me.WaitLabel.AutoSize = True
        Me.WaitLabel.Location = New System.Drawing.Point(204, 342)
        Me.WaitLabel.Name = "WaitLabel"
        Me.WaitLabel.Size = New System.Drawing.Size(155, 13)
        Me.WaitLabel.TabIndex = 15
        Me.WaitLabel.Text = "Wait Between Repetitions (min)"
        '
        'WaitNumber
        '
        Me.WaitNumber.Location = New System.Drawing.Point(363, 339)
        Me.WaitNumber.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.WaitNumber.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.WaitNumber.Name = "WaitNumber"
        Me.WaitNumber.Size = New System.Drawing.Size(45, 20)
        Me.WaitNumber.TabIndex = 16
        Me.WaitNumber.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'ExposureNumber
        '
        Me.ExposureNumber.Location = New System.Drawing.Point(596, 339)
        Me.ExposureNumber.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.ExposureNumber.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.ExposureNumber.Name = "ExposureNumber"
        Me.ExposureNumber.Size = New System.Drawing.Size(47, 20)
        Me.ExposureNumber.TabIndex = 17
        Me.ExposureNumber.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'ExposureLabel
        '
        Me.ExposureLabel.AutoSize = True
        Me.ExposureLabel.Location = New System.Drawing.Point(513, 341)
        Me.ExposureLabel.Name = "ExposureLabel"
        Me.ExposureLabel.Size = New System.Drawing.Size(77, 13)
        Me.ExposureLabel.TabIndex = 18
        Me.ExposureLabel.Text = "Exposure (sec)"
        '
        'AnalyzeButton
        '
        Me.AnalyzeButton.Location = New System.Drawing.Point(9, 383)
        Me.AnalyzeButton.Name = "AnalyzeButton"
        Me.AnalyzeButton.Size = New System.Drawing.Size(70, 26)
        Me.AnalyzeButton.TabIndex = 19
        Me.AnalyzeButton.Text = "Analyze"
        Me.AnalyzeButton.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(104, 390)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Reference Filter"
        '
        'ReferenceFilter
        '
        Me.ReferenceFilter.Location = New System.Drawing.Point(192, 388)
        Me.ReferenceFilter.Maximum = New Decimal(New Integer() {7, 0, 0, 0})
        Me.ReferenceFilter.Name = "ReferenceFilter"
        Me.ReferenceFilter.Size = New System.Drawing.Size(31, 20)
        Me.ReferenceFilter.TabIndex = 21
        Me.ReferenceFilter.Value = New Decimal(New Integer() {3, 0, 0, 0})
        '
        'ReferenceTemperature
        '
        Me.ReferenceTemperature.Location = New System.Drawing.Point(339, 388)
        Me.ReferenceTemperature.Maximum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.ReferenceTemperature.Minimum = New Decimal(New Integer() {50, 0, 0, -2147483648})
        Me.ReferenceTemperature.Name = "ReferenceTemperature"
        Me.ReferenceTemperature.Size = New System.Drawing.Size(42, 20)
        Me.ReferenceTemperature.TabIndex = 23
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(246, 390)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Reference Temp"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(519, 300)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 13)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Current Temp"
        '
        'TemperatureReadout
        '
        Me.TemperatureReadout.AutoSize = True
        Me.TemperatureReadout.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TemperatureReadout.Location = New System.Drawing.Point(593, 300)
        Me.TemperatureReadout.Name = "TemperatureReadout"
        Me.TemperatureReadout.Size = New System.Drawing.Size(13, 13)
        Me.TemperatureReadout.TabIndex = 25
        Me.TemperatureReadout.Text = "0"
        '
        'FocusProfilerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(653, 421)
        Me.Controls.Add(Me.TemperatureReadout)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ReferenceTemperature)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ReferenceFilter)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.AnalyzeButton)
        Me.Controls.Add(Me.ExposureLabel)
        Me.Controls.Add(Me.ExposureNumber)
        Me.Controls.Add(Me.WaitNumber)
        Me.Controls.Add(Me.WaitLabel)
        Me.Controls.Add(Me.RepetitionsLabel)
        Me.Controls.Add(Me.RepetitionsNumber)
        Me.Controls.Add(Me.ClearFilterNumber)
        Me.Controls.Add(Me.ClearFilterLabel)
        Me.Controls.Add(Me.PreFocusButton)
        Me.Controls.Add(Me.ZBFSLabel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LastFilterNumber)
        Me.Controls.Add(Me.FirstFilterLabel)
        Me.Controls.Add(Me.FirstFilterNumber)
        Me.Controls.Add(Me.DoneButton)
        Me.Controls.Add(Me.StopButton)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.ProfileDataBox)
        Me.Name = "FocusProfilerForm"
        Me.Text = "Focus Temperature Profiler (Ver 1.6)"
        CType(Me.FirstFilterNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LastFilterNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClearFilterNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepetitionsNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WaitNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ExposureNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReferenceFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReferenceTemperature, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ProfileDataBox As System.Windows.Forms.TextBox
    Friend WithEvents StartButton As System.Windows.Forms.Button
    Friend WithEvents StopButton As System.Windows.Forms.Button
    Friend WithEvents DoneButton As System.Windows.Forms.Button
    Friend WithEvents FirstFilterNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents FirstFilterLabel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LastFilterNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents ZBFSLabel As System.Windows.Forms.Label
    Friend WithEvents PreFocusButton As System.Windows.Forms.Button
    Friend WithEvents FocusFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ClearFilterLabel As System.Windows.Forms.Label
    Friend WithEvents ClearFilterNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents AFToolTips As System.Windows.Forms.ToolTip
    Friend WithEvents RepetitionsNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents RepetitionsLabel As System.Windows.Forms.Label
    Friend WithEvents WaitLabel As System.Windows.Forms.Label
    Friend WithEvents WaitNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents ExposureNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents ExposureLabel As System.Windows.Forms.Label
    Friend WithEvents AnalyzeButton As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ReferenceFilter As System.Windows.Forms.NumericUpDown
    Friend WithEvents ReferenceTemperature As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TemperatureReadout As System.Windows.Forms.Label
End Class
