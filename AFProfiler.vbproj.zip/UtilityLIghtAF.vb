﻿Imports System.IO

'Windows Visual Basic Class: UtilityLightAF
'
'Culled down verion of TTUtilities module for use with the Focus/Temperature Profile Application
'
' ------------------------------------------------------------------------
'
' Author: R.McAlister (2015)
' Version 1.0
'
' ------------------------------------------------------------------------

Public Class TTutility
    'Common utilities for TSX connections
    '
    Public Shared Target_Name
    Public Shared Cam_Delay
    Public Shared Cam_Reduction
    Public Shared Cam_Filter
    Public Shared Cam_Exposure
    Public Shared AG_Reduction
    Public Shared AG_Exposure
    Public Shared AG_Delay
    Public Shared AG_MinMove
    Public Shared AG_Aggressiveness

    Public Shared ConfigName
    Public Shared FocuserName
    Public Shared FilterCountText
    Public Shared FilterCount

    Public Const SettlingTime = 5
    Const FtextFields = 2
    Const FtextColorField = 0
    Const FtextDataField = 1
    Const FdataFieldCount = 4
    Const FfilterNumberIndex = 0
    Const FdateDataOffset = 0
    Const FposDataOffset = 1
    Const FtempDataOffset = 3

    Public Shared Sub SaveTSXState()

        'Saves the current target and camera configuration information in TTutility public variables
        '   Target Name (for TSX Find)
        '   Camera Delay
        '   Camera Exposure
        '   Camera Image Reduction
        '   Camera Filter

        'target name
        Dim tsx_oi = CreateObject("TheSkyX.Sky6ObjectInformation")
        tsx_oi.Property(theskyxLib.Sk6ObjectInformationProperty.sk6ObjInfoProp_NAME1)
        Target_Name = tsx_oi.ObjInfoPropOut
        'camera configuration
        Dim tsx_cc = CreateObject("TheSkyX.ccdsoftCamera")
        Cam_Delay = tsx_cc.Delay
        Cam_Reduction = tsx_cc.ImageReduction
        Cam_Filter = tsx_cc.FilterIndexZeroBased
        Cam_Exposure = tsx_cc.ExposureTime
        'guider configuration
        Dim tsx_ag = CreateObject("TheSkyX.ccdsoftCamera")
        tsx_ag.Autoguider = 1
        AG_Delay = tsx_ag.Delay
        AG_Reduction = tsx_ag.ImageReduction
        AG_Exposure = tsx_ag.ExposureTime
        AG_MinMove = tsx_ag.AutoguiderMinimumMove
        AG_Aggressiveness = tsx_ag.AutoguiderAggressiveness

        tsx_oi = Nothing
        tsx_cc = Nothing
        tsx_ag = Nothing
        Return
    End Sub


    Public Shared Sub RestoreTSXState()

        'Clears the observing list, restores the current target and camera configuration information in TTutility public variables,
        'Open camera object
        Dim tsx_cc = CreateObject("TheSkyX.ccdsoftCamera")

        'target star
        TSX_Find(Target_Name)
        'camera settings
        tsx_cc.ImageReduction = Cam_Reduction
        tsx_cc.FilterIndexZeroBased = Cam_Filter
        tsx_cc.ExposureTime = Cam_Exposure
        tsx_cc.Delay = Cam_Delay
        'autoguider settings
        Dim tsx_ag = CreateObject("TheSkyX.ccdsoftCamera")
        tsx_ag.Autoguider = 1
        tsx_ag.Delay = AG_Delay
        tsx_ag.ImageReduction = AG_Reduction
        tsx_ag.ExposureTime = AG_Exposure
        tsx_ag.AutoguiderMinimumMove = AG_MinMove
        tsx_ag.AutoguiderAggressiveness = AG_Aggressiveness
        'Clean up
        tsx_cc = Nothing
        tsx_ag = Nothing
        Return

    End Sub

    Public Shared Function ClosedLoopSlew(clearfilter As Integer, ExposureTime As Double) As Integer
        'Calls a TSX Closed Loop Slew using the whatever target is in the current Find
        'A successful slew will return zero.

        Dim CLSstatus As Integer
        'Open camera object
        Dim tsx_cc = CreateObject("TheSkyX.ccdsoftCamera")

        'If CLS is required, then create cls object, set the exposure, filter to luminance and reduction, set the camera delay to 15
        ' should be picked up in the mount driver

        Dim tsx_cls = CreateObject("TheSkyX.ClosedLoopSlew")
        tsx_cc.ImageReduction = theskyxLib.ccdsoftImageReduction.cdAutoDark
        tsx_cc.FilterIndexZeroBased = clearfilter
        tsx_cc.ExposureTime = ExposureTime
        tsx_cc.Delay = SettlingTime 'Set some settling time for the mount

        Try
            CLSstatus = tsx_cls.exec()
        Catch ex As Exception
            'Just close up: TSX will spawn error window
            CLSstatus = -1
        End Try

        'Clean up
        tsx_cls = Nothing
        Return (CLSstatus)
    End Function


    Public Shared Sub TSX_Find(targetname As String)
        'Clears all entries in observing list, in absence of same function in TSX automation
        'Upon clearing, the routine will "find" the target name, if any 

        If targetname <> Nothing Then
            Dim tsx_sc = CreateObject("TheSkyX.Sky6StarChart")
            Try
                tsx_sc.Find(targetname)
            Catch ex As Exception
                'Continue
            End Try
            tsx_sc = Nothing
        End If
        Return
    End Sub

    Public Shared Function checkTSX() As Boolean
        Dim pname As String = "TheSkyX"
        Dim pList() As System.Diagnostics.Process = System.Diagnostics.Process.GetProcesses
        For Each proc As System.Diagnostics.Process In pList
            If String.Compare(proc.ProcessName, pname) = 0 Then
                Return True
            End If
        Next
        MsgBox("TSX is not open")
        Return False
    End Function

    Public Shared Sub TSXWaitLoop(tsx_cc As Object)
        Do While tsx_cc.state = theskyxLib.ccdsoftCameraState.cdStateTakePicture
            System.Threading.Thread.Sleep(1000)
        Loop
        Return
    End Sub

    Public Shared Function GetFOCdata(focFilePath As String) As String(,)

        'Opens and interpolates .foc file for luminance filter, returns computed position in steps based on Current Temperature 

        'File and filter data structure

        'Open foc file
    
        Dim sr As New StreamReader(focFilePath)
        Try
            Dim FocuserCount = sr.ReadLine()
        Catch e As Exception
            MsgBox("The focus file could not be found: " + e.Message)
            Return (Nothing)
        End Try

        'Open, read in and partially parse the focus file to a text array, then close it up 
        ConfigName = sr.ReadLine()
        FocuserName = sr.ReadLine()
        FilterCountText = sr.ReadLine()
        FilterCount = Int(FilterCountText)

        Dim ftextdata((FilterCount - 1), (FtextFields - 1)) As String

        Dim ftextrecord As Integer = 0
        For ftextrecord = 0 To FilterCount - 1
            ftextdata(ftextrecord, FtextColorField) = sr.ReadLine()
            ftextdata(ftextrecord, FtextDataField) = sr.ReadLine()
        Next
        sr.Close()
        Return ftextdata
    End Function

    Public Shared Function GetFilterName(ftextdata, filter) As String
        Dim fname_filter() = Split(ftextdata(filter, FtextColorField), ",")
        Return fname_filter(0)
    End Function

    Public Shared Function GetfilterCount(ftextdata) As Integer
        Return (FilterCount)
    End Function

    Public Shared Function ComputePosition(ftextdata, filter, currenttemp) As Integer
        'Parse out the Luminance data
        Dim fdata_filter() = Split(ftextdata(filter, FtextDataField), ",")
        Dim focdatacount = (fdata_filter.Length - 1) / FdataFieldCount
        If focdatacount < 2 Then
            'MsgBox("Too few datapoints to compute")
            Return (0)
        End If
        'parse out temp and position tuples for filter
        Dim tempdata() As Double
        Dim posdata() As Double

        For i = 0 To focdatacount - 1
            ReDim Preserve posdata(i)
            posdata(i) = fdata_filter((i * FdataFieldCount) + FposDataOffset + 1)
            ReDim Preserve tempdata(i)
            tempdata(i) = fdata_filter((i * FdataFieldCount) + FtempDataOffset + 1)
        Next
        Dim currentpoint = CalculatePosition(posdata, tempdata, currenttemp)
        Return currentpoint

    End Function

    Public Shared Function ComputeSlope(ftextdata, filter) As Integer
        'Parse out the Luminance data
        Dim fdata_filter() = Split(ftextdata(filter, FtextDataField), ",")
        Dim focdatacount = (fdata_filter.Length - 1) / FdataFieldCount
        If focdatacount < 2 Then
            'MsgBox("Too few datapoints to compute")
            Return (0)
        End If
        'parse out temp and position tuples for luminance
        Dim tempdata() As Double
        Dim posdata() As Double
        Dim i As Integer
        For i = 0 To focdatacount - 1
            ReDim Preserve posdata(i)
            posdata(i) = fdata_filter((i * FdataFieldCount) + FposDataOffset + 1)
            ReDim Preserve tempdata(i)
            tempdata(i) = fdata_filter((i * FdataFieldCount) + FtempDataOffset + 1)
        Next
        Dim currentslope = CalculateSlope(posdata, tempdata)

        Return currentslope

    End Function

    Public Shared Function CalculatePosition(PositionData, TemperatureData, Temperature) As Double
        'Compute Least Mean Squares slope and intercept for focus data

        Dim posmean As Double = 0
        Dim tempmean As Double = 0
        Dim datacount As Integer = PositionData.length

        For i = 0 To datacount - 1
            posmean += PositionData(i)
            tempmean += TemperatureData(i)
        Next
        posmean = posmean / datacount
        tempmean = tempmean / datacount
        Dim sumtemppos As Double = 0
        Dim sumtemp As Double = 0
        For i = 0 To datacount - 1
            sumtemppos += (PositionData(i) - posmean) * (TemperatureData(i) - tempmean)
            sumtemp += (TemperatureData(i) - tempmean) ^ 2
        Next
        Dim slope = sumtemppos / sumtemp
        Dim intercept = posmean - (slope * tempmean)
        'Compute position for current temp
        'Dim currentposition = intercept + slope * currenttemp

        'Return the computed position for the given temperature
        Return (intercept + slope * Temperature)

    End Function

    Public Shared Function CalculateSlope(PositionData, TemperatureData) As Double
        'Compute Least Mean Squares slope and intercept for focus data

        Dim posmean As Double = 0
        Dim tempmean As Double = 0
        Dim datacount As Integer = PositionData.length

        For i = 0 To datacount - 1
            posmean += PositionData(i)
            tempmean += TemperatureData(i)
        Next
        posmean = posmean / datacount
        tempmean = tempmean / datacount
        Dim sumtemppos As Double = 0
        Dim sumtemp As Double = 0
        For i = 0 To datacount - 1
            sumtemppos += (PositionData(i) - posmean) * (TemperatureData(i) - tempmean)
            sumtemp += (TemperatureData(i) - tempmean) ^ 2
        Next
        'Dim slope = sumtemppos / sumtemp
        'Dim intercept = posmean - (slope * tempmean)
        'Compute position for current temp

        'Return the computed position for the given temperature
        Return (sumtemppos / sumtemp)

    End Function


    Public Shared Function DoubleClip(ByVal dvalue As Double, ByVal decimals As Integer) As String
        'Converts a double value (dvalue) to a string truncated to the specified number (decimals) of decimal points, adds a leading 0 if necessary
        Dim ss As String
        Dim decpos As Integer

        ss = Str(Math.Round(dvalue * 100) / 100)
        decpos = InStr(ss, ".")
        If (decpos <> 0) And (decpos + 2 < ss.Length) Then
            ss = Strings.Left(ss, decpos + 2)
        End If
        ss = LTrim(ss)
        If dvalue < 1 Then
            ss = "0" + ss
        End If
        Return (ss)
    End Function


End Class
